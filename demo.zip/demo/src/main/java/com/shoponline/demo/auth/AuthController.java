package com.shoponline.demo.auth;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dto.auth.AuthRequest;
import com.dto.auth.AuthResponse;
import com.model.Role;
import com.model.User;
import com.service.UserService;
import com.springweb.demo.security.JwtUtil;

import jakarta.validation.Valid;



@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final UserService userService;

    public AuthController(AuthenticationManager authenticationManager, JwtUtil jwtUtil, UserService userService) {
    this.authenticationManager = authenticationManager;
    this.jwtUtil = jwtUtil;
    this.userService = userService;
    }

    @PostMapping("/register")
public ResponseEntity<?> register(@Valid @RequestBody AuthRequest request) {
    try {
        Role role = Role.USER; // O el valor que necesites según tu enum
        User user = userService.register(
            request.getUsername(),   // ahora sí se usa un username real
            request.getPassword(), 
            request.getEmail(), 
            role
        );
        return ResponseEntity.ok(user); // Puedes devolver solo ciertos campos si lo prefieres
    } catch (IllegalArgumentException e) {
        return ResponseEntity
            .badRequest()
            .body("Error: " + e.getMessage());
    } catch (Exception e) {
        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body("Unexpected error occurred");
    }
}

@PostMapping("/login")
public ResponseEntity<?> login(@Valid @RequestBody AuthRequest request) {
   Authentication auth = authenticationManager.authenticate(
    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

    String token = jwtUtil.generateToken(request.getEmail());
    return ResponseEntity.ok(new AuthResponse(token));
}

}
