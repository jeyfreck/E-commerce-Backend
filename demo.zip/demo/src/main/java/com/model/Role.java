package com.model;

public enum Role {
    ADMIN,
    CLIENT,
    USER;
}
