package com.model;

import java.util.List;

import com.audit.Auditable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Cart extends Auditable{

@Id
@GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
private Long id;

@OneToOne
private User user;

@ManyToMany
private List<Product> products;

private int totalItems;
private double totalPrice;

public Long getId() {
    return id;
}
public void setId(Long id) {
    this.id = id;
}
public User getUser() {
    return user;
}
public void setUser(User user) {
    this.user = user;
}
public List<Product> getProducts() {
    return products;
}
public void setProducts(List<Product> products) {
    this.products = products;
}
public int getTotalItems() {
    return totalItems;
}
public void setTotalItems(int totalItems) {
    this.totalItems = totalItems;
}
public double getTotalPrice() {
    return totalPrice;
}
public void setTotalPrice(double totalPrice) {
    this.totalPrice = totalPrice;
}


}
