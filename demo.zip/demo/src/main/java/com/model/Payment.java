package com.model;

import java.time.LocalDateTime;

import com.audit.Auditable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Payment extends Auditable{
    
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private double amount;

private String method; // e.g., "credit card", "paypal" etc.

private LocalDateTime paymentDate; 

private String status; // e.g., "completed", "pending", "failed"

@OneToOne
private Order order;

public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public double getAmount() {
    return amount;
}

public void setAmount(double amount) {
    this.amount = amount;
}

public String getMethod() {
    return method;
}

public void setMethod(String method) {
    this.method = method;
}

public LocalDateTime getPaymentDate() {
    return paymentDate;
}

public void setPaymentDate(LocalDateTime paymentDate) {
    this.paymentDate = paymentDate;
}

public String getStatus() {
    return status;
}

public void setStatus(String status) {
    this.status = status;
}

public Order getOrder() {
    return order;
}

public void setOrder(Order order) {
    this.order = order;
}


}
