package com.model;

import com.audit.Auditable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class ShippingAddress extends Auditable{

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String recipientName;

private String streetAddress;

private String city;

private String state;

private String country;

@ManyToOne
private User user;

public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public String getRecipientName() {
    return recipientName;
}

public void setRecipientName(String recipientName) {
    this.recipientName = recipientName;
}

public String getStreetAddress() {
    return streetAddress;
}

public void setStreetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
}

public String getCity() {
    return city;
}

public void setCity(String city) {
    this.city = city;
}

public String getState() {
    return state;
}

public void setState(String state) {
    this.state = state;
}

public String getCountry() {
    return country;
}

public void setCountry(String country) {
    this.country = country;
}

public User getUser() {
    return user;
}

public void setUser(User user) {
    this.user = user;
} 


}
