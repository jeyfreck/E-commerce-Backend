package com.audit;

import java.time.LocalDateTime;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

public class AuditListener {
    
@PrePersist
public void setCreatedAt(Object entity) {
    if (entity instanceof Auditable) {
        ((Auditable) entity).setCreatedAt(LocalDateTime.now());
        ((Auditable) entity).setUpdatedAt(LocalDateTime.now());
    }
}

@PreUpdate
public void setUpdatedAt(Object entity) {
    if (entity instanceof Auditable) {
        ((Auditable) entity).setUpdatedAt(LocalDateTime.now());
    }
}
}