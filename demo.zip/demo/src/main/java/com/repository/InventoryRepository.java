package com.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Inventory;
import com.model.Product;

public interface  InventoryRepository extends JpaRepository<Inventory, Long> {
    Optional<Inventory> findByProduct(Product product);
    
}
