package com.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.CartItem;
import com.model.Product;
import com.model.User;

public interface  CartItemRepository extends JpaRepository<CartItem, Long> {
List<CartItem> findByUserId(User user);
Optional<CartItem> findByUserIdAndProductId(User user, Product product);
void deleteByUser(User user);    
    
    
}
