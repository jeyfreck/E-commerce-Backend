package com.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dto.ProductDTO;
import com.model.Product;
import com.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/product")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
    this.productService = productService;
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/products")
    public ResponseEntity<Product> create(@Valid @RequestBody ProductDTO dto) {
        
    return ResponseEntity.ok(productService.createProduct(dto));
    }
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @GetMapping
    public List<Product> listAll() {
    return productService.getAllProducts();
    }
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @GetMapping("/{id}")
    public ResponseEntity<Product> getById(@PathVariable Long id) {
    return productService.getProductById(id)
    .map(ResponseEntity::ok)
    .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public List<Product> searchByName(@RequestParam String name) {
    return productService.searchByName(name);
    }

    @GetMapping("/category")
    public List<Product> filterByCategory(@RequestParam String category){
    return productService.filterByCategory(category);
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<Product> update(@PathVariable Long id,  
    @Valid @RequestBody ProductDTO dto) {
    return ResponseEntity.ok(productService.updateProduct(id, dto));
    }
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
    productService.deleteProduct(id);
    return ResponseEntity.noContent().build();
    }

}
