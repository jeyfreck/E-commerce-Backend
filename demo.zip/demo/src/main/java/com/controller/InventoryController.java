package com.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.Inventory;
import com.service.InventoryService;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

private final InventoryService inventoryService;

public InventoryController(InventoryService inventoryService) {
this.inventoryService = inventoryService;
}

@PostMapping("/set/{productId}")
public ResponseEntity<Inventory> setStock(@PathVariable Long productId, 
@RequestParam int quantity) {
Inventory updated = inventoryService.setStock(productId, quantity);
return ResponseEntity.ok(updated);
}

@GetMapping("/{productId}")
public ResponseEntity<Inventory> getStock(@PathVariable Long productId) {
Inventory inventory = inventoryService.getStock(productId);
return ResponseEntity.ok(inventory);
}

@GetMapping
public ResponseEntity<List<Inventory>> getAll(){
return ResponseEntity.ok(inventoryService.getAllStock());
}

@DeleteMapping("/{productId}")
public ResponseEntity<Void> deleteStock(@PathVariable Long productId) {
inventoryService.deleteStock(productId);
return ResponseEntity.noContent().build();
}
}
