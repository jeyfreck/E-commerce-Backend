package com.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.ShippingAddress;
import com.service.ShippingAddressService;

@RestController
@RequestMapping("/api/shipping-addresses")
public class ShippingAddresController {

    private final ShippingAddressService shippingAddressService;

    public ShippingAddresController(ShippingAddressService shippingAddressService) {
        this.shippingAddressService = shippingAddressService;
    }
    @PreAuthorize("hasRole('USER')")
    @PostMapping("/user/{userId}")
    public ResponseEntity<ShippingAddress> addAddress(@PathVariable Long userId,
            @RequestBody ShippingAddress address) {
        ShippingAddress savedAddress = shippingAddressService.saveAddress(userId, address);
        return ResponseEntity.ok(savedAddress);
    }
    @PreAuthorize("hasRole('USER')")
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<ShippingAddress>> getUserAddresses(@PathVariable Long userId) {
        List<ShippingAddress> addresses = shippingAddressService.getUserAddresses(userId);
        return ResponseEntity.ok(addresses);
    }
    @PreAuthorize("hasRole('USER')")
    @DeleteMapping("/{addressId}")
    public ResponseEntity<Void> deleteAddress(@PathVariable Long addressId) {
        shippingAddressService.deleteAddress(addressId);
        return ResponseEntity.noContent().build();
    }
}
