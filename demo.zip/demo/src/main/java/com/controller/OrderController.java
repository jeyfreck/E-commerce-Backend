package com.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.Order;
import com.service.OrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

private final OrderService orderService;

public OrderController(OrderService orderService) {
this.orderService = orderService;
}
@PreAuthorize("hasRole('USER')")
@PostMapping
public ResponseEntity<Order> createOrder(@Valid @RequestParam Long userId, 
@RequestParam List<Long>
 productIds) {

Order newOrder = orderService.createOrder(userId, productIds);
return ResponseEntity.ok(newOrder);
}
@PreAuthorize("hasRole('ADMIN')")
@GetMapping
public ResponseEntity<List<Order>> getAllOrders() {
return ResponseEntity.ok(orderService.getAllOrders());
}
@PreAuthorize("hasAnyRole('ADMIN', 'USER')")
@GetMapping("/{id}")
public ResponseEntity<Order> getOrderById(@Valid @PathVariable Long id) {
return orderService.getOrderById(id)
.map(ResponseEntity::ok)
.orElse(ResponseEntity.notFound().build());
}

@DeleteMapping("/{id}")
public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
orderService.deleteOrder(id);
return ResponseEntity.noContent().build();
}

}