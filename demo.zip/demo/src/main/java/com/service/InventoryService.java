package com.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.model.Inventory;
import com.model.Product;
import com.repository.InventoryRepository;
import com.repository.ProductRepository;

@Service
public class InventoryService {
    
private final InventoryRepository inventoryRepository;
private final ProductRepository productRepository;

public InventoryService(InventoryRepository inventoryRepository, ProductRepository productRepository) {
this.inventoryRepository = inventoryRepository;
this.productRepository = productRepository;
 }

public Inventory setStock(Long productId, int quantity) {
Optional<Product> productOpt = productRepository.findById(productId);

if (productOpt.isEmpty()) {
throw new RuntimeException("Product not found");
}

Product product = productOpt.get();
Optional<Inventory> inventoryOpt = inventoryRepository.findByProduct(product);

Inventory inventory = inventoryOpt.orElse(new Inventory());
inventory.setProduct(product);
inventory.setQuantity(quantity);
return inventoryRepository.save(inventory);

} 

public Inventory getStock(Long productId){
Product product = productRepository.findById(productId).orElseThrow(() -> 
new RuntimeException("Product not found"));

return inventoryRepository.findByProduct(product).orElseThrow(() -> new 
RuntimeException("Inventory not found"));
}

public List<Inventory> getAllStock() {
return inventoryRepository.findAll();
}

public void deleteStock(Long productId) {
Product product = productRepository.findById(productId).orElseThrow(() -> new 
RuntimeException("Product not found"));

Inventory inventory = inventoryRepository.findByProduct(product).orElseThrow(() -> new
RuntimeException("Inventory not found"));
inventoryRepository.delete(inventory);
}
}
