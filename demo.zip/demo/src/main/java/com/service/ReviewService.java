package com.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Product;
import com.model.Review;
import com.model.User;
import com.repository.ProductRepository;
import com.repository.ReviewRepository;
import com.repository.UserRepository;

@Service
public class ReviewService {

private final ReviewRepository reviewRepository;
private final ProductRepository productRepository;
private final UserRepository userRepository;

public ReviewService(ReviewRepository reviewRepository, ProductRepository productRepository,
 UserRepository userRepository) {
this.reviewRepository = reviewRepository;
this.productRepository = productRepository;
this.userRepository = userRepository;
}

public List<Review> getReviewsByProductId(Long productId) {
Product product = productRepository.findById(productId).orElseThrow(() -> new
RuntimeException("Product not found"));
return reviewRepository.findByProduct(product);
}

public Review addUpdateReview(Long userId, Long productId, int rating, String comment) {
Product product = productRepository.findById(productId).orElseThrow(() -> new RuntimeException(
"Product not found"));

User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException(
"User not found"));

return reviewRepository.findByProductAndUser(product, user).map(existingReview -> {
existingReview.setRating(rating);
existingReview.setComment(comment);
return reviewRepository.save(existingReview);
})
.orElseGet(() -> {
Review review = new Review();
review.setProduct(product);
review.setUser(user);
review.setRating(rating);
review.setComment(comment);
return reviewRepository.save(review);
});
}

public void deleteReview(Long reviewId) {
if (!reviewRepository.existsById(reviewId)) {
throw new RuntimeException("Review not found");
}
reviewRepository.deleteById(reviewId);
}
}