package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dto.ProductDTO;
import com.model.Product;
import com.repository.ProductRepository;

@Service
public class ProductService {
    
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product createProduct(ProductDTO dto) {
        Product product = new Product(
        dto.getName(), 
        dto.getDescription(), dto.getPrice(),
        dto.getCategory(), dto.getStock());
        return productRepository.save(product);
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

     public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    public List<Product> searchByName(String name) {
        return productRepository.findByNameContainingIgnoreCae(name);
    }

    public List<Product> filterByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    public Product updateProduct(Long id, ProductDTO dto) {
        Optional<Product> existingProduct = productRepository.findById(id);

        if (existingProduct.isPresent()) {
            Product product = existingProduct.get();
            product.setName(dto.getName());
            product.setCategory(dto.getCategory());
            product.setPrice(dto.getPrice());
            
            return productRepository.save(product);
        } else {
            throw new RuntimeException("Product with ID " + id + " not found");
        }
    }
}
