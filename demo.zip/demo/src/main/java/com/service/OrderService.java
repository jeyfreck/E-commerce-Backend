package com.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.model.User;

import org.springframework.stereotype.Service;

import com.model.Order;
import com.model.Product;
import com.repository.OrderRepository;
import com.repository.ProductRepository;
import com.repository.UserRepository;

@Service
public class OrderService {

private final OrderRepository orderRepository;
private final UserRepository userRepository;
private final ProductRepository productRepository;

public OrderService(OrderRepository orderRepository, UserRepository userRepository, 
ProductRepository productRepository) {
this.orderRepository = orderRepository;
this.userRepository = userRepository;
this.productRepository = productRepository;
 }

public Order createOrder(Long userId, List<Long> productIds) {
Optional<User> userOptional = userRepository.findById(userId);
if (!userOptional.isPresent()) {
throw new RuntimeException("User not found");
}
List<Product> products = productRepository.findAllById(productIds);
Double total = products.stream().mapToDouble(Product::getPrice).sum();
Order order = new Order();
order.setOrderDate(LocalDateTime.now());
order.setUser(userOptional.get());
order.setProducts(products);
order.setTotalPrice(total);

return orderRepository.save(order);

 }

public List<Order> getAllOrders() {
return orderRepository.findAll();
 }

public Optional<Order> getOrderById(Long id) {
return orderRepository.findById(id);
}

public void deleteOrder(Long id) {
orderRepository.deleteById(id);
}
}
