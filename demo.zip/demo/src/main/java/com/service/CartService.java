package com.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Cart;
import com.model.Product;
import com.model.User;
import com.repository.CartRepository;
import com.repository.ProductRepository;
import com.repository.UserRepository;

@Service
public class CartService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public CartService(CartRepository cartRepository, ProductRepository productRepository, UserRepository userRepository) {
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    public Cart getCartByUserId(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        return cartRepository.findByUser(user).orElseGet(() -> createEmtyCart(user));
    }

    public Cart addProductsToCart(Long userId, List<Long> productsIds) {
        Cart cart = getCartByUserId(userId);
        List<Product> products = productRepository.findAllById(productsIds);
        cart.getProducts().addAll(products);
        updateCartTotals(cart);
        return cartRepository.save(cart);

    }

    public Cart removeProductFromCart(Long userId, Long productId) {
        Cart cart = getCartByUserId(userId);
        cart.getProducts().removeIf(p -> p.getId().equals(productId));
        updateCartTotals(cart);
        return cartRepository.save(cart);
    }

    public void clearCart(Long userId) {
        Cart cart = getCartByUserId(userId);
        cart.getProducts().clear();
        updateCartTotals(cart);
        cartRepository.save(cart);
    }

    private void updateCartTotals(Cart cart) {
        cart.setTotalItems(cart.getProducts().size());
        cart.setTotalPrice(cart.getProducts().stream().mapToDouble(Product::getPrice).sum());

    }

    private Cart createEmtyCart(User user) {
        Cart cart = new Cart();
        cart.setUser(user);
        cart.setProducts(new java.util.ArrayList<>());
        cart.setTotalItems(0);
        cart.setTotalPrice(0.0);
        return cartRepository.save(cart);
    }
}
