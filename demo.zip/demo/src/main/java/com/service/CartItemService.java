package com.service;


import java.util.List;


import org.springframework.stereotype.Service;

import com.model.CartItem;
import com.model.Product;
import com.model.User;
import com.repository.CartItemRepository;
import com.repository.ProductRepository;
import com.repository.UserRepository;

@Service
public class CartItemService {
    
private final CartItemRepository cartItemRepository;
private final ProductRepository productRepository;
private final UserRepository userRepository;

public CartItemService(CartItemRepository cartItemRepository, ProductRepository productRepository, UserRepository userRepository) {
this.cartItemRepository = cartItemRepository;
this.productRepository = productRepository;
this.userRepository = userRepository;

}

public CartItem addToCart(Long userId, Long productId, int quantity) {
User user = userRepository.findById(userId).orElseThrow(() -> new 
RuntimeException("User not found"));

Product product = productRepository.findById(productId).orElseThrow(() -> new 
RuntimeException("Product not found"));

CartItem cartItem = cartItemRepository.findByUserIdAndProductId(user, product)
.orElse(new CartItem());

cartItem.setUser(user);
cartItem.setProduct(product);
cartItem.setQuantity(cartItem.getId()== null ? quantity : cartItem.getQuantity() + quantity);
return cartItemRepository.save(cartItem);
}

public List<CartItem> getCart(Long userId) {
User user = userRepository.findById(userId).orElseThrow(() -> new 
RuntimeException("User not found"));
return cartItemRepository.findByUserId(user);
}

public void removeFromCart(Long userId, Long productId) {
User user = userRepository.findById(userId).orElseThrow(() -> new 
RuntimeException("User not found"));

Product product = productRepository.findById(productId).orElseThrow(() -> new 
RuntimeException("Product not found"));

cartItemRepository.findByUserIdAndProductId(user, product)
.ifPresent(cartItemRepository::delete);
}

public void clearCart(Long userId) {
User user = userRepository.findById(userId).orElseThrow(() -> new 
RuntimeException("User not found"));

cartItemRepository.deleteByUser(user);
}
}