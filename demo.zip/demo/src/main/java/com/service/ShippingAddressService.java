package com.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.model.ShippingAddress;
import com.model.User;
import com.repository.ShippingAddressRepository;
import com.repository.UserRepository;

@Service
public class ShippingAddressService {

    private final ShippingAddressRepository shippingAddressRepository;
    private final UserRepository userRepository;

    public ShippingAddressService(ShippingAddressRepository shippingAddressRepository, UserRepository userRepository) {
        this.shippingAddressRepository = shippingAddressRepository;
        this.userRepository = userRepository;
    }

    public ShippingAddress saveAddress(Long userId, ShippingAddress address) {
        Optional<User> userOpt = userRepository.findById(userId);

        if (userOpt.isEmpty()) {
            throw new RuntimeException("User not found");
        }
        address.setUser(userOpt.get());
        return shippingAddressRepository.save(address);
    }

    public List<ShippingAddress> getUserAddresses(Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) {
            throw new RuntimeException("User not found");
        }
        return shippingAddressRepository.findByUserId(userOpt.get());
    }

    public void deleteAddress(Long addressId) {
        shippingAddressRepository.deleteById(addressId);
    }
}
