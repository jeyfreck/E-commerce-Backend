export function getToken() {
    return localStorage.getItem('token');
  }
  
  export function authHeader() {
    return { 'Authorization': `Bearer ${getToken()}` };
  }