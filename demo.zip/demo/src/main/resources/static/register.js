document.getElementById('registerForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();
  const confirmPassword = document.getElementById('confirmPassword').value.trim();

  if (password !== confirmPassword) {
    alert('Passwords do not match!');
    return;
  }

  try {
    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ username, email, password })
    });

    if (response.ok) {
      alert('Registration successful!');
      window.location.href = 'login.html';
    } else {
      const errorText = await response.text();
      alert('Registration failed: ' + errorText);
    }
  } catch (error) {
    console.error('Registration error:', error);
    alert('An error occurred while registering.');
  }
});
