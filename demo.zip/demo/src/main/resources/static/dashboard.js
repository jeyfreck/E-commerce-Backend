
import { authHeader } from './utils.js';

window.onload = async () => {
  const res = await fetch('/api/user', { headers: authHeader() });
  const users = await res.json();
  const list = document.getElementById('userList');
  users.forEach(u => {
    const li = document.createElement('li');
    li.textContent = `${u.id} - ${u.email}`;
    list.appendChild(li);
  });
};
