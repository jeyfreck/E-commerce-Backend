document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });

    if (response.ok) {
      const data = await response.json();
      localStorage.setItem('token', data.token);
      alert('Login successful!');
      window.location.href = 'dashboard.html'; // Redirige a la vista principal
    } else {
      const errorText = await response.text();
      alert('Login failed: ' + errorText);
    }
  } catch (error) {
    console.error('Login error:', error);
    alert('An error occurred while logging in.');
  }
});
