# E-commerce Backend API

A modular and secure RESTful API built with **Spring Boot** for managing an e-commerce platform.  
Created by **Keyron Fernández Freckleton** as a personal project to apply clean architecture, auditing, and role-based authorization.

---

## Features

- **Role-based access control** (`USER`, `ADMIN`)
- **Product**, **Cart**, **Order**, **Payment**, and **User** management
- **Audit logging** using JPA entity listeners
- **DTOs and Validation** for clean request handling
- **Modular architecture** (Controller, Service, Repository)
- Ready for integration with any frontend (e.g. React, Angular)

---

## Technologies

- Java 17+
- Spring Boot
- Spring Security
- JPA / Hibernate
- Maven
- MySQL (or any JPA-compatible DB)


---

## Project Structure

```
src/main/java/com/
├── controller         # REST controllers
├── dto               # Data transfer objects
├── model             # JPA entities
├── repository        # Database interfaces
├── service           # Business logic
├── audit             # Entity auditing
└── config            # Security configuration
```

---

## Endpoints Overview

- `POST /auth/register` — User registration  
- `POST /auth/login` — JWT authentication  
- `GET /products` — Public product listing  
- `POST /products` — Create product (**ADMIN only**)  
- `POST /orders` — Place an order (**USER only**)  

*Includes many more endpoints for carts, payments, shipping, etc.*

---

## Getting Started

# Build the project
./mvnw clean install

# Run the app
./mvnw spring-boot:run
```

Make sure to configure your database in `application.properties`.

---

## To Do

- Add unit and integration tests
- Swagger API documentation
- Paginación and advanced filtering
- Dockerize the app

---

## Author

**Keyron Fernández Freckleton**   
Feel free to connect or reach out!